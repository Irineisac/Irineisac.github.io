# Patient-Monitoring-System
A full fledged patient monitoring system with usecase diagrams SRS and sequence diagrams.
<img width="1440" alt="software_gui" src="https://user-images.githubusercontent.com/94536401/147399729-57a1ebbf-cae8-48b7-86b8-9f4282e9bd2c.png">
